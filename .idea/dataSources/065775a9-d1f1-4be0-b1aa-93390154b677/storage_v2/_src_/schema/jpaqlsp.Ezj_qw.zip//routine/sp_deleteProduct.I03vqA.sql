create
    definer = root@localhost procedure sp_deleteProduct(IN inputId mediumtext)
BEGIN
DELETE FROM products WHERE id=inputId;
END;

