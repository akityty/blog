create
    definer = root@localhost procedure sp_findByName(IN inputName varchar(255))
BEGIN
select * from products where products.name like inputName;
END;

