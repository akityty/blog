create
    definer = root@localhost procedure sp_findById(IN inputId mediumtext)
BEGIN
select * from products where id = inputId;
END;

