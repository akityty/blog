create
    definer = root@localhost procedure sp_addBlog(IN inputCreateDate datetime, IN inputTittle varchar(255),
                                                  IN inputCategory varchar(255), IN inputContent text,
                                                  IN inputImage varchar(255))
BEGIN
INSERT INTO blogs (
createDate
, tittle
, category
, content
, image)
   VALUES (inputCreateDate
   , inputTittle
   , inputCategory
   , inputContent
   , inputImage);
END;

