create
    definer = root@localhost procedure sp_updateProduct(IN inputId mediumtext, IN inputActive int,
                                                        IN inputCreateDate datetime, IN inputDescription varchar(255),
                                                        IN inputImage varchar(255), IN inputName varchar(255),
                                                        IN inputPrice double, IN inputQuantity double)
BEGIN
update products
set 
active = inputActive,
createDate = inputCreateDate,
description = inputDescription,
image = inputImage,
name = inputName,
price = inputPrice,
quantity = inputQuantity
where id = inputId;
END;

