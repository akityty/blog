create
    definer = root@localhost procedure sp_findAllProduct()
BEGIN
select * from products;
END;

